    #include<stdio.h>  
    #include<stdlib.h>  
    struct node  
    {  
        struct node *prev;  
        struct node *next;  
        int data;  
    };  
    struct node *head;  
    void insertion_beginning();  
    void insertion_last();  
    void main ()  
    {  
    int choice =0;  
        while(choice != 9)  
        {  
            
            printf("\nChoose one option from the following list ...\n");    
            printf("\n1.Insert in begining\n2.Insert at last\n");  
            printf("\nEnter your choice?\n");  
            scanf("\n%d",&choice);  
            switch(choice)  
            {  
                case 1:  
                insertion_beginning();  
                break;  
                case 2:  
                        insertion_last();  
                break;  
                
                default:  
                printf("Please enter valid choice..");  
            }  
        }  
    }  
    void insertion_beginning()  
    {  
       struct node *ptr;   
       int item;  
       ptr = (struct node *)malloc(sizeof(struct node));  
       if(ptr == NULL)  
       {  
           printf("\nOVERFLOW");  
       }  
       else  
       {  
        printf("\nEnter Item value");  
        scanf("%d",&item);  
          
       if(head==NULL)  
       {  
           ptr->next = NULL;  
           ptr->prev=NULL;  
           ptr->data=item;  
           head=ptr;  
       }  
       else   
       {  
           ptr->data=item;  
           ptr->prev=NULL;  
           ptr->next = head;  
           head->prev=ptr;  
           head=ptr;  
       }  
       printf("\nNode inserted\n");  
    }  
         
    }  
    void insertion_last()  
    {  
       struct node *ptr,*temp;  
       int item;  
       ptr = (struct node *) malloc(sizeof(struct node));  
       if(ptr == NULL)  
       {  
           printf("\nOVERFLOW");  
       }  
       else  
       {  
           printf("\nEnter value");  
           scanf("%d",&item);  
            ptr->data=item;  
           if(head == NULL)  
           {  
               ptr->next = NULL;  
               ptr->prev = NULL;  
               head = ptr;  
           }  
           else  
           {  
              temp = head;  
              while(temp->next!=NULL)  
              {  
                  temp = temp->next;  
              }  
              temp->next = ptr;  
              ptr ->prev=temp;  
              ptr->next = NULL;  
              }  
                 
           }  
         printf("\nnode inserted\n");  
        }  
   
